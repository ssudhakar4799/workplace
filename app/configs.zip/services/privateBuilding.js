"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const pvtBulding = mongoose.model("pvtBuilding");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");
const pvtEmission = mongoose.model("pvtemissions");

class PvtBuilding {

    async pvtCreateBuilding(req, res) {
        try {

            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let pvtEmision = await pvtEmission.findOne({ _id: req.payload.emissionId })
            console.log(pvtEmision);

            let pvtBuildings = new pvtBulding(req.payload);
            // console.log(buildings);

           

            pvtBuildings = await pvtBuildings.save();
            return jsend("successfully enter in to the create Building pages", pvtBuildings)

        }
        catch (error) {
            console.log(error);
            res.notAcceptable(error)

        }
    }

     // UPDATE BUILDING DETAILS

     async pvtUpdateBuildingDetails(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

             // USER SELECTION OF CHECK FOR VEHICLES OR 
             let pvtEmision = await pvtEmission.findOne({ _id: req.payload.emissionId })
             console.log(pvtEmision);
 

            //    data pass of values
            let pvtUpdateBulding = await pvtBulding.findOne({ _id: req.payload.pvtBuildingId });

            if (pvtUpdateBulding) {
                _.each(Object.keys(req.payload), (key) => {
                    pvtUpdateBulding[key] = req.payload[key];
                });

                // Building calculation of convertion Factors STARTING 

                let object = pvtUpdateBulding;

                function calculateCostOfPeriod(data) {
                    let totalCost = 0;
                    let electricityTotalEmissions;
                    let gasTotalEmissions;
                    let oilTotalEmissions;
                    let lpgTotalEmissions;
                    let biofuelsTotalEmissions;
                    let coalTotalEmissions;
                    let coolingCostTotalEmissions;
    
                    // Electricity cost.
                    if (data.electricity.isUsedPeriod) {
                        // electricity total emisssion
                        electricityTotalEmissions=  data.electricity.costOfPeriod / 0.34 * 0.207074;
                        data.electricity.electricityTotalEmission = electricityTotalEmissions;
                        // all total emissions
                        totalCost +=electricityTotalEmissions
    
                    }
    
                    // Heating cost.
                    for (const heatedType of data.heatingUp.heatedTypes) {
                        if (heatedType.type == "gas") {
                            // gas total emissions
                            gasTotalEmissions = heatedType.costOfPeriod / 7.51 * 0.2;
                            heatedType.totalEmission = gasTotalEmissions;
                            // all total emissions
                            totalCost += gasTotalEmissions;
                        }
                        if (heatedType.type == "oil") {
                            // oil total emissions
                            oilTotalEmissions = heatedType.costOfPeriod / 1.02 * 2.76;
                            heatedType.totalEmission = oilTotalEmissions
                            // all total emissions
                            totalCost += oilTotalEmissions;
                        }
                        if (heatedType.type == "lpg") {
                            // lpg total emissions
                            lpgTotalEmissions = heatedType.costOfPeriod / 0.77 * 1.17;
                            heatedType.totalEmission = lpgTotalEmissions;
                            // all total emissions
                            totalCost += lpgTotalEmissions;
                        }
                        if (heatedType.type == "bioFuel") {
                            // biofuel total emissions
                            biofuelsTotalEmissions = heatedType.costOfPeriod / 2.35 * 0.35;
                            heatedType.totalEmission = biofuelsTotalEmissions;
                            // all total emissions
                            totalCost += biofuelsTotalEmissions;
                        }
                        if (heatedType.type == "coal") {
                            // coal total emissions
                            coalTotalEmissions = heatedType.costOfPeriod / 0.5 * 0.32;
                            heatedType.totalEmission = coalTotalEmissions;
                            // all total emissions
                            totalCost += coalTotalEmissions;
                        }
                    }
    
                    // Cooling cost.
                    if (data.coolingDown.isUsedPeriod) {
                        // cost total emissions
                        coolingCostTotalEmissions = data.coolingDown.costOfPeriod / 13.1 * 1300;
                        data.coolingDown.coolingDownTotalEmssion = coolingCostTotalEmissions;
                        // all total emissions
                        totalCost += coolingCostTotalEmissions
                    }
    
                    // Generatior calculations
                    let naturalGasTotalEmission;
                    let dieselTotalEmissions;
                    let propaneTotalEmissions;
                    let petrolTotalEmissions;
    
                    // Generator cost.
                    for (const generatorType of data.generators.generatorTypes) {
                        if (generatorType.type == "naturalGas") {
                            // naturalGas total emissions
                            naturalGasTotalEmission = generatorType.costOfPeriod / 7.51 * 2.02;
                            generatorType.totalEmission = naturalGasTotalEmission;
                            // all total emissions
                            totalCost += naturalGasTotalEmission;
                        }
                        if (generatorType.type == "diesel") {
                            // diesel total emissions
                            dieselTotalEmissions = generatorType.costOfPeriod / 1 * 2.53;
                            generatorType.totalEmission = dieselTotalEmissions;
                            // all total emissions
                            totalCost += dieselTotalEmissions;
                        }
                        if (generatorType.type == "propane") {
                            // propane total emissions
                            propaneTotalEmissions = generatorType.costOfPeriod / 1 * 1.54;
                            generatorType.totalEmission = propaneTotalEmissions;
                            // all total emissions
                            totalCost += propaneTotalEmissions;
                        }
                        if (generatorType.type == "petrol") {
                            // petrol total emissions
                            petrolTotalEmissions = generatorType.costOfPeriod / 1 * 2.1;
                            generatorType.totalEmission = petrolTotalEmissions;
                            // all total emissions
                            totalCost += petrolTotalEmissions;
                        }
                    }
    
                    return totalCost;
                }
    
                const totalCost = calculateCostOfPeriod(object);
    
                // set of building total emissions
                pvtUpdateBulding.buildingTotalEmissions = totalCost;
    
                console.log(totalCost); // 150
    
                console.log(pvtUpdateBulding);
                
                // Building calculation of convertion Factors ENDING

                // userReporting generations functionality
                findUser.reportingStatus = true;
                findUser.initialPayment = false;

                const result = await pvtUpdateBulding.save();
                findUser = await findUser.save();
                const updated = await pvtBulding.findOne({ _id: req.payload.pvtBuildingId });
                return jsend(200, "Successfully Building details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the Building details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

}
module.exports = PvtBuilding