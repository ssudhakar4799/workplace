"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const user = mongoose.model("user");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");


class Subscription {
    async createSubscription(req, res) {
        try {
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // // userFind Details
            let users = await user.findOne({ _id: req.payload.userId });
            console.log(users);

            // users.userType = subscriptions.userType;
            // users.paymentType = subscriptions.paymentType
            // console.log(users);

            // subscription details datas
            let subscriptions = new subscription(req.payload);
            console.log(subscriptions);
            if (subscriptions.paymentType?.oneTimePayment.payDate) {
                subscriptions.paymentType.oneTimePayment.isActive = true;
                let oneTimeExpiredDate = moment(subscriptions.paymentType.oneTimePayment.payDate).add(1, 'months').format('YYYY-MM-DD');
                subscriptions.paymentType.oneTimePayment.expiredDate = oneTimeExpiredDate;

                // user payment details pass of userDetails
                users.initialPayment = true;
                users.expiredDate = oneTimeExpiredDate;
                users.paymentType = "oneTimePayment";
                
            }
            if (subscriptions.paymentType?.monthlySubscriber.payDate) {
                subscriptions.paymentType.monthlySubscriber.isActive = true;
                let mothlySubscribeExDate = moment(subscriptions.paymentType.monthlySubscriber.payDate).add(1, 'months').format('YYYY-MM-DD');
                subscriptions.paymentType.monthlySubscriber.expiredDate = mothlySubscribeExDate;

                // user payment details pass of userDetails
                users.initialPayment = true;
                users.expiredDate = mothlySubscribeExDate;
                users.paymentType = "monthlySubscribers";
            }

            // user details save fuctions
            subscriptions = await subscriptions.save();
            users = await users.save();

            return jsend(200, "createSubscription Successfully", subscriptions)

        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }
}
module.exports = Subscription