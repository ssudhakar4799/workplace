"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const user = mongoose.model("user");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const jwt = serviceLocator.get("jwt");
// const student = mongoose.model("students")
const config = require("../configs/configs")();
const bcrypt = serviceLocator.get("bcrypt");
const nodemailer = serviceLocator.get("nodemailer");
const otpGenerator = serviceLocator.get("otpgenerator");



class USER {
    async createUserProflie(req, res) {
        try {
            // already exist
            const userExist = await user.findOne({ email: req.payload.email });
            console.log(userExist);

            if (userExist) {
                return jsend(400, "email already exiting")
            }

            // Token Generate
            let jwtSecretKey = config.jwt.secretKey;
            let expiration = config.jwt.expiration

            let users = new user(req.payload)
            let userID = users._id;
            console.log(userID,"userId");
            // const salt = await bcrypt.genSalt(10);
            users.password = await bcrypt.hashSync(req.payload.password, 10);

            // Set Token
            users.token = await jwt.sign({ _id: userID }, jwtSecretKey,{expiresIn:expiration});

            let userRegisterDetails = {
                userId : userID,
                token : users.token,
                companyName:users.companyName,
                previousEmission:users.previousEmission=null,
                resumeEmission:users.resumeEmission=null
            }


            // create-user
            users = await users.save();
            return jsend(200, "Successfully User Profile was Created ", userRegisterDetails);

        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // update user

    async updateUser(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            //    data pass of values
            let updateCourse = await user.findOne({ _id: req.payload.id });
            if (updateCourse) {
                _.each(Object.keys(req.payload), (key) => {
                    updateCourse[key] = req.payload[key];
                });
                const result = await updateCourse.save();
                const updated = await user.findOne({ _id: req.payload.id });
                return jsend(200, "Successfully User details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the User details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

    // delete user

    async deleteUser(req, res) {
        try {
            // token validation part
            console.log(token);
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }
            // delete user details
            let deleteUserDetails = await user.findOne({ _id: req.payload.id });
            if (deleteUserDetails) {
                let deleteUserDetailss = await user.deleteOne({ _id: req.payload.id });
                return jsend(200, "Successfully User Profile was deleted");
            } else {
                return jsend(400, "Failed to deleted the User Profile");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // find particular user
    async findOneUser(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let userLogIndetails = await user.findOne({ _id: req.payload.id });

            let userDetails = {
                userId:userLogIndetails._id,
               userType:userLogIndetails.userType,
               initialPayment:userLogIndetails.initialPayment ? userLogIndetails.initialPayment: false,
               expiredDate:userLogIndetails.expiredDate ? userLogIndetails.expiredDate : null,
               reportingStatus:userLogIndetails?.reportingStatus ? userLogIndetails.reportingStatus : false,
               emissionStatus: userLogIndetails?.reportingStatus ? null : userLogIndetails.emissionStatus,
               paymentType: userLogIndetails.paymentType ? userLogIndetails.paymentType : null,
               createVehicles:userLogIndetails.createVehicleDetails ? userLogIndetails.createVehicleDetails : null,
               previousEmission : userLogIndetails.previousEmission ? userLogIndetails.previousEmission : null,
               resumeEmission:userLogIndetails.resumeEmission ? userLogIndetails.resumeEmission : null

            }

            if (findUser) {
                return jsend(200, "successfully fetched the Particular User Profile", userDetails);
            } else {
                return jsend(400, "Failed to fetched the all User Profile");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // find All user
    async findAllUser(req, res) {
        try {
            // let obj = {}
            // if (req.payload.access) {
            //     obj.access = req.payload.access
            
            // }

            let findUser = await user.find({});
            if (findUser) {
                return jsend(200, "successfully fetched the all User Profile", findUser);
            } else {
                return jsend(400, "Failed to fetched the all User Profile");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // userLogin Details
    async loginDetails(req, res) {
        try {

            let userLogIndetails;
            let userID = "";
            userLogIndetails = await user.findOne({ email: req.payload.email });
            console.log(userLogIndetails);
            if (!userLogIndetails) {
            } else {
                userID = userLogIndetails._id;
            }
            let jwtSecretKey = config.jwt.secretKey;
            let expiration = config.jwt.expiration
            if (userLogIndetails) {

                let passwordcheck = await bcrypt.compareSync(req.payload.password, userLogIndetails.password);
                if (passwordcheck) {
                    userLogIndetails.token = await jwt.sign({ _id: userID }, jwtSecretKey,{expiresIn:expiration});
                    let userDetails = {
                        userId:userLogIndetails._id,
                       token: userLogIndetails.token,
                       userType:userLogIndetails.userType,
                       initialPayment:userLogIndetails.initialPayment ? userLogIndetails.initialPayment: false,
                       expiredDate:userLogIndetails.expiredDate ? userLogIndetails.expiredDate : null,
                       reportingStatus:userLogIndetails?.reportingStatus ? userLogIndetails.reportingStatus : false,
                       emissionStatus: userLogIndetails?.reportingStatus ? null : userLogIndetails.emissionStatus,
                       paymentType: userLogIndetails.paymentType ? userLogIndetails.paymentType : null
                    }
                    return jsend(200, "successfully login the page", userDetails);
                } else {
                    return jsend(400, "invailed password or email");
                }
            } else {
                return jsend(400, "failed to find the user");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // generate otp for email
    async generatorOTP(req, res) {
        try {
            let userLogIndetails;
            userLogIndetails = await user.findOne({ email: req.payload.email });

            if (userLogIndetails) {
                let forGetPassword = await otpGenerator.generate(6, { digits: true, lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });

                userLogIndetails.otp = forGetPassword;
                userLogIndetails = await userLogIndetails.save()

                let transport = nodemailer.createTransport({
                    service: 'gmail',
                    host: "smtp.gmail.com",
                    auth: {
                        user: config.email.emailID,
                        pass: config.email.emailpassword,
                    }
                });
                let info = ({
                    html: `<html><body>Hi,<br>your sceret otp is ${`https://fabevy.com/`}.<br><br>regards & thanks<br>LightHouse</body></html>`,
                    from: config.email.emailID,
                    to: req.payload.email,
                    subject: "OTP VERIFY",
                    text:`https://fabevy.com/`

                });
                transport.sendMail(info);
                return jsend(200, "successfully mail sended", info);
            } else {
                return jsend(400, "email id does not exist");
            }

        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // verifyOtp
    async verifyOtp(req, res) {
        try {
            let userLogIndetails;
            userLogIndetails = await user.findOne({ email: req.payload.email });
            console.log(userLogIndetails);
            if (userLogIndetails) {
                if (userLogIndetails.otp == req.payload.otp) {
                    return jsend(200, "successfully otp verify", userLogIndetails);
                } else {
                    return jsend(400, "invailed otp")
                }
            } else {
                return jsend(400, "Failed to find the user");
            }
        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // user forget password

    async genNewPassword(req, res) {
        try {
            let userProflie;
            userProflie = await user.findOne({ email: req.payload.email });
            if (!userProflie) {
                userProflie = await student.findOne({ email: req.payload.email });
            }
            if (userProflie) {
                userProflie.password = await bcrypt.hashSync(req.payload.password, 10);
                userProflie = await userProflie.save()
                return jsend(200, "successfully Created newpassword", userProflie);
            } else {
                return jsend(400, "Failed to find the user");
            }
        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

}
module.exports = USER