"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const PvtSubscripe = mongoose.model("pvtSubscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const user = mongoose.model("user");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");


class PvtSubscription {
    async pvtcreateSubscription(req, res) {
        try {

            // // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let users = await user.findOne({ _id: req.payload.userId });
            console.log(users);
            
            // subscription details datas
            let pvtSubcription = new PvtSubscripe(req.payload);

            if (pvtSubcription.paymentType.oneTimePayment.payDate) {
                pvtSubcription.paymentType.oneTimePayment.isActive = true;
                let oneTimeExpiredDate = moment(pvtSubcription.paymentType.oneTimePayment.payDate).add(1, 'month').format('YYYY-MM-DD');
                pvtSubcription.paymentType.oneTimePayment.expiredDate = oneTimeExpiredDate;
                
                users.initialPayment = true;
                users.expiredDate = oneTimeExpiredDate;
            }
          
            pvtSubcription = await pvtSubcription.save();
            // user details save fuctions
            users = await users.save();

            return jsend(200, "createSubscription Successfully", pvtSubcription)

        } catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }



}
module.exports = PvtSubscription