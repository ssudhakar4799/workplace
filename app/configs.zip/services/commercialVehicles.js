"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const emission = mongoose.model("emissions");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const vehicles = mongoose.model("vehicles");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");
const conFacVehicle = mongoose.model("commercialVehicleConverion");


class Vehicles {
    async createVehicles(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let emision = await emission.findOne({ _id: req.payload.userId });
            console.log(emision);
            // fuels
            let vehicle = new vehicles(req.payload)
            // set of userId
            // vehicle.userId = findUser._id
            // DATA FOR STORE OF DB
            findUser.createVehicleDetails = vehicle;
            findUser = await findUser.save();
            vehicle = await vehicle.save();
            return jsend(200, "Successfully Vehicles was Created ", vehicle);
        }
        catch (e) {
            console.log(e);
            res.notAcceptaple(e);
        }

    }

    // findone vehicles details
    async findOneUserVehicles(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let findOneUsersVehicles = await vehicles.findOne({ _id: req.payload.id });
            if (findOneUsersVehicles) {
                return jsend(200, "successfully fetched the Particular Vehicle Profile", findOneUsersVehicles);
            } else {
                return jsend(400, "Failed to fetched the all Vehicle Profile");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // find one user created vehicles list
    async findOneUserAllVechicles(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let findOneUsersVehicles = await vehicles.find({ emissionId: req.payload.emissionId });
            if (findOneUsersVehicles) {
                return jsend(200, "successfully fetched the Particular User Profile", findOneUsersVehicles);
            } else {
                return jsend(400, "Failed to fetched the all User Profile");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // UPDATE VEHICLE DETAILS

    async updateVehicleDetails(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let emision = await emission.findOne({ _id: req.payload.emissionId });
            console.log(emision);

            // CONVERTION FACTORS DETAILS 
            let conFactVehicle = await conFacVehicle.find({});
            //  console.log(conFactVehicle);
            //  latest update details
            let latestDetails = conFactVehicle[conFactVehicle.length - 1];
            console.log(latestDetails);

            //    data pass of values
            let updateVehicles = await vehicles.findOne({ _id: req.payload.vehicleId });
            console.log(updateVehicles);


            if (updateVehicles) {
                _.each(Object.keys(req.payload), (key) => {
                    updateVehicles[key] = req.payload[key];         
                });

                // --------------------------------startingVehcilesCalculations--------------------------

                let object = updateVehicles;
                let totalLitersOfPeriod = 0;
                let multipleFuleTotal = 0;
                let fuelsTotalEmission;
                let fuelOilTotalEmission;
                let lubricantsTotalEmission;
                let trailerRefrigerationTotalEmission;
                let airConditionTotalEmission;

                // // calculate the all values

                let Co2=0;
                let Ch4=0;
                let N2O=0;

                // Iterate over the object and add the litersOfPeriod property to the total.
                for (const property in object) {
                    // fuels strting sections
                    if (object[property] && object[property]) {
                        // -----------------diesel------------------------
                        if (object[property] && object[property].diesel?.milleage >=0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].diesel.milleage * latestDetails.fuels.diesel.Co2e_of_Co2_unit
                            let Ch41 = object[property].diesel.milleage * latestDetails.fuels.diesel.Co2e_of_Ch4_unit
                            let N2O1 = object[property].diesel.milleage * latestDetails.fuels.diesel.Co2e_of_N2O_unit
                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            updateVehicles.fuels.diesel.dieselEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.diesel.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission

                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // -----------------bioPetrol------------------------
                        if (object[property] && object[property].bioPetrol?.milleage >=0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].bioPetrol.milleage * latestDetails.fuels.bioPetrol.Co2e_of_Co2_unit
                            let Ch41 = object[property].bioPetrol.milleage * latestDetails.fuels.bioPetrol.Co2e_of_Ch4_unit
                            let N2O1 = object[property].bioPetrol.milleage * latestDetails.fuels.bioPetrol.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelsTotalEmission = object[property].bioPetrol.milleage * 2.1;
                            updateVehicles.fuels.bioPetrol.bioPetrolEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.bioPetrol.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission
                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // -----------------mineralPetrol------------------------
                        if (object[property] && object[property].mineralPetrol?.milleage >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].mineralPetrol.milleage * latestDetails.fuels.mineralPetrol.Co2e_of_Co2_unit
                            let Ch41 = object[property].mineralPetrol.milleage * latestDetails.fuels.mineralPetrol.Co2e_of_Ch4_unit
                            let N2O1 = object[property].mineralPetrol.milleage * latestDetails.fuels.mineralPetrol.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;

                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelsTotalEmission = object[property].mineralPetrol.milleage * 2.32567;
                            updateVehicles.fuels.mineralPetrol.mineralPetrolEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.mineralPetrol.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission
                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // -----------------lpg------------------------
                        if (object[property] && object[property].lpg?.milleage >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].lpg.milleage * latestDetails.fuels.lpg.Co2e_of_Co2_unit
                            let Ch41 = object[property].lpg.milleage * latestDetails.fuels.lpg.Co2e_of_Ch4_unit
                            let N2O1 = object[property].lpg.milleage * latestDetails.fuels.lpg.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelsTotalEmission = object[property].lpg.milleage * 1.55491;
                            updateVehicles.fuels.lpg.lpgEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.lpg.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission
                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // -----------------lnc------------------------
                        if (object[property] && object[property].lng?.milleage >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].lng.milleage * latestDetails.fuels.lng.Co2e_of_Co2_unit
                            let Ch41 = object[property].lng.milleage * latestDetails.fuels.lng.Co2e_of_Ch4_unit
                            let N2O1 = object[property].lng.milleage * latestDetails.fuels.lng.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelsTotalEmission = object[property].lng.milleage * 1.15583;
                            updateVehicles.fuels.lng.lncEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.lng.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission
                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // -----------------cng------------------------
                        if (object[property] && object[property].cng?.milleage >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].cng.milleage * latestDetails.fuels.cng.Co2e_of_Co2_unit
                            let Ch41 = object[property].cng.milleage * latestDetails.fuels.cng.Co2e_of_Ch4_unit
                            let N2O1 = object[property].cng.milleage * latestDetails.fuels.cng.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;

                            fuelsTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelsTotalEmission = object[property].cng.milleage * 0.44353;
                            updateVehicles.fuels.cng.cngEmission = fuelsTotalEmission;
                            // completed status add step
                            updateVehicles.fuels.cng.isComplete = true;
                            // only Fuels total emission
                            multipleFuleTotal += fuelsTotalEmission
                            // all totall emission
                            totalLitersOfPeriod += fuelsTotalEmission;
                        }
                        // only fules total emission
                        updateVehicles.fuels.fuelsStatus = true;
                        updateVehicles.fuels.fuelTotalEmission = multipleFuleTotal;
                    }
                    // fuels end sections
                    // fuelOil starting sections
                    if (object[property] && object[property]) {
                        // -----------------fuelOil------------------------
                        if (object[property] && object[property].fuelOil?.litersOfPeriod >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].fuelOil.litersOfPeriod * latestDetails.fuelOil.Co2e_of_Co2_unit
                            let Ch41 = object[property].fuelOil.litersOfPeriod * latestDetails.fuelOil.Co2e_of_Ch4_unit
                            let N2O1 = object[property].fuelOil.litersOfPeriod * latestDetails.fuelOil.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            fuelOilTotalEmission = Co21 + Ch41 + N2O1;
                            // fuelOilTotalEmission = object[property].fuelOil.litersOfPeriod * 3.17;
                            updateVehicles.fuelOil.fuelOilEmission = fuelOilTotalEmission;
                            // completed status add step
                            updateVehicles.fuelOil.isComplete = true;
                            // all totall emission
                            totalLitersOfPeriod += fuelOilTotalEmission;
                        }
                        // -----------------lubricants------------------------
                        if (object[property] && object[property].lubricants?.litersOfPeriod >= 0) {
                            // let co2 = latestDetails.
                            let Co21 = object[property].lubricants.litersOfPeriod * latestDetails.lubricants.Co2e_of_Co2_unit
                            let Ch41 = object[property].lubricants.litersOfPeriod * latestDetails.lubricants.Co2e_of_Ch4_unit
                            let N2O1 = object[property].lubricants.litersOfPeriod * latestDetails.lubricants.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            lubricantsTotalEmission = Co21 + Ch41 + N2O1;
                            // lubricantsTotalEmission = object[property].lubricants.litersOfPeriod * 2.75;
                            updateVehicles.lubricants.lubricantsEmission = lubricantsTotalEmission;
                            // completed status add step
                            updateVehicles.lubricants.isComplete = true;
                            // all totall emission
                            totalLitersOfPeriod += lubricantsTotalEmission;
                        }

                    }
                    if (object[property] && object[property]) {
                        // -----------------trailerRefrigeration------------------------
                        if (object[property] && object[property].trailerRefrigeration?.spentMoney >= 0) {
                            // let co2 = latestDetails.
                            let price = latestDetails.trailerRefrigeration.price;
                            let co2total = latestDetails.trailerRefrigeration.Co2e_unit;
                            let totalEmission = object[property].trailerRefrigeration.spentMoney / price;
                            let Co21 = totalEmission * latestDetails.trailerRefrigeration.Co2e_of_Co2_unit
                            let Ch41 = totalEmission * latestDetails.trailerRefrigeration.Co2e_of_Ch4_unit
                            let N2O1 = totalEmission * latestDetails.trailerRefrigeration.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            let trialTotal = Co21+Ch41+N2O1
                            trailerRefrigerationTotalEmission = trialTotal;

                            // trailerRefrigerationTotalEmission = object[property].trailerRefrigeration.spentMoney / 18.45 * 1120;
                            updateVehicles.trailerRefrigeration.trailerRefrigerationEmission = trailerRefrigerationTotalEmission;
                            // completed status add step
                            updateVehicles.trailerRefrigeration.isComplete = true;
                            // all totall emission
                            totalLitersOfPeriod += trailerRefrigerationTotalEmission;
                        }
                        // -----------------airCondition------------------------
                        if (object[property] && object[property]?.airCondition?.spentMoney >= 0) {
                            // let co2 = latestDetails.
                            let price = latestDetails.airCondition.price;
                            let co2total = latestDetails.airCondition.Co2e_unit;
                            let totalEmission = object[property].airCondition.spentMoney / price;
                            // let airTotalEmission = totalEmission * co2total
                            let Co21 = totalEmission * latestDetails.airCondition.Co2e_of_Co2_unit
                            let Ch41 = totalEmission * latestDetails.airCondition.Co2e_of_Ch4_unit
                            let N2O1 = totalEmission * latestDetails.airCondition.Co2e_of_N2O_unit

                            Co2 += Co21;
                            Ch4 +=Ch41;
                            N2O += N2O1;
                            let trialTotal = Co21+Ch41+N2O1
                            airConditionTotalEmission = trialTotal;
                            // airConditionTotalEmission = object[property].airCondition.spentMoney / 13.1 * 1300;
                            updateVehicles.airCondition.airConditionEmission = airConditionTotalEmission;
                            // completed status add step
                            updateVehicles.airCondition.isComplete = true;
                            updateVehicles.vehicleStatus = true;

                            // all total emission
                            totalLitersOfPeriod += airConditionTotalEmission;
                            emision.vehicleStatus = true;
                        }

                    }

                }
                updateVehicles.Co2totalEmission = Co2;
                updateVehicles.Ch4totalEmission = Ch4;
                updateVehicles.N2OtotalEmission = N2O;
                // ASSIN FOR ALL EMISSION IN DB STORE AND CALULATIONS
                updateVehicles.vehiclesTotalEmission = totalLitersOfPeriod;
                // --------------------------------endingVehcilesCalculations--------------------------

                // report generatior functions

                if (findUser.paymentType == "oneTimePayment") {
                    if (emision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = true;
                        findUser.initialPayment = false;
                    }
                    if (emision.buildings.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        findUser.initialPayment = true;
                    }
                    if (emision.buildings.isActive && emision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        findUser.initialPayment = true;
                    }
                }
                else if (findUser.paymentType == "monthlySubscribers") {
                    if (emision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = true;
                        // findUser.initialPayment = false;
                    }
                    if (emision.buildings.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        // findUser.initialPayment = true;
                    }
                    if (emision.buildings.isActive && emision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        // findUser.initialPayment = true;
                    }
                }

                const emissionSave = await emision.save();
                const result = await updateVehicles.save();
                const updated = await vehicles.findOne({ _id: req.payload.vehicleId });
                findUser.createVehicleDetails = updated;

                findUser = await findUser.save();
                return jsend(200, "Successfully Vehicle details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the Vehicle details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

}

module.exports = Vehicles;