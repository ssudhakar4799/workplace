"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const pvtConVehicles = mongoose.model("pvtVehicleConverion");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class PvtConVehicles{
    async pvtCreatecomConVehicle (req,res) {
        try{
            let pvtConVehicle = new pvtConVehicles(req.payload);
            pvtConVehicle = await pvtConVehicle.save();
            return jsend(200, "Successfully Convetion Factors was Created ", pvtConVehicle);
        }
        catch(e){
            console.log(e);
            res.notAcceptaple(e)
        }
       
    }
}

module.exports = PvtConVehicles;