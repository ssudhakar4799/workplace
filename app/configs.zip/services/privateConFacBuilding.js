"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const pvtConBuildings = mongoose.model("pvtBuildingConvertion");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class PvtConBuilding{
    async pvtCreatecomConBuilding (req,res) {
        try{
            console.log(req.payload);
            let pvtConBuilding = new pvtConBuildings(req.payload);
            pvtConBuilding = await pvtConBuilding.save();
            return jsend(200, "Successfully Convetion Factors was Created ", pvtConBuilding);
        }
        catch(e){
            console.log(e);
            res.notAcceptaple(e);
        }
       
    }
}

module.exports = PvtConBuilding;