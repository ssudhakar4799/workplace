"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const pvtemissions = mongoose.model("pvtemissions");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class PvtEmission {
    async pvtcreateEmission(req, res) {
        try {

            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let pvtemition = new pvtemissions(req.payload);
            console.log(pvtemition);
            // let userSelection = req.payload
            // if(userSelection.vehicles){
            //     emition.vehicles.isActive = true;
            //     emition.vehicles.status = "Active"
            // }
            // else{

            // }
            // pending status emition id setup
            findUser.emissionStatus = {
                pendingStatus: true,
                emissionId:pvtemition._id
            }
            // added values
            pvtemition.userId = findUser._id;
            // create-user
            pvtemition = await pvtemition.save();
            findUser = await findUser.save();
            return jsend(200, "Successfully Emission was Created ", pvtemition);
        }
        catch (e) {
            console.log(e);
            res.notAcceptaple(e)
        }

    }

    // UPDATE EMISSIONS

    async pvtUpdateEmissions(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            //    data pass of values
            let pvtUpdateCourse = await pvtemissions.findOne({ _id: req.payload.emissionId });
            if (pvtUpdateCourse) {
                _.each(Object.keys(req.payload), (key) => {
                    pvtUpdateCourse[key] = req.payload[key];
                });
                const result = await pvtUpdateCourse.save();
                const updated = await pvtemissions.findOne({ _id: req.payload.emissionId });
                return jsend(200, "Successfully User details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the User details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }
}

module.exports = PvtEmission;