"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const emissions = mongoose.model("emissions");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class Emission{
    async createEmission (req,res) {
        try{

            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let emition = new emissions(req.payload);
            console.log(emition);

            // pending status emition id setup
            findUser.emissionStatus = {
                pendingStatus: true,
                emissionId:emition._id,
                emissionsDetails:emition,
                previousEmission:null,
                resumeEmission:null
            }
            findUser.resumeEmission = emition._id

            
            // emission setup datas
            emition.vehicleStructure = {
                "resumStatus":null,
                "vehicleId":null,
                "emissionId":null,
                "userId":null,
                "fuels":{
                    "diesel":{
                        "isUsedPeriod":false,
                        "milleage":0
                    },
                    "bioPetrol":{
                        "isUsedPeriod":false,
                        "milleage":0
                    },
                    "mineralPetrol":{
                        "isUsedPeriod":false,
                        "milleage":0
                    },
                    "lpg":{
                        "isUsedPeriod":false,
                        "milleage":0
                    },
                    "lnc":{
                        "isUsedPeriod":false,
                        "milleage":0
                    },
                    "cng":{
                        "isUsedPeriod":false,
                        "milleage":0
                    }
                },
                    "fuelOil":{
                    "isUsedPeriod":false,
                    "litersOfPeriod":0
                },
                "lubricants":{
                    "isUsedPeriod":false,
                    "litersOfPeriod":0
                }, 
                "airCondition":{
                    "isUsedPeriod":false,
                    "spentMoney":0
                },
                "trailerRefrigeration":{
                    "isUsedPeriod":false,
                    "spentMoney":0
                }
            }
            // emition.buildingSchema.requestDetails = {
            //     "buildingId":null,
            //     "emissionId":null,
            //     "electricity": {
            //     "isUsedPeriod": false,
            //     "costOfPeriod": 0
            //   },
            //   "heatingUp": {
            //     "isUsedPeriod": false,
            //     "heatedTypes": [
            //       {
            //         "type": "gas",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       },
            //       {
            //         "type": "oil",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       },
            //       {
            //         "type": "lpg",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       },
            //        {
            //         "type": "bioFuel",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       },
            //        {
            //         "type": "coal",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       }
            //     ]
            //   },
            //   "coolingDown": {
            //     "isUsedPeriod": false,
            //     "costOfPeriod": 0
            //   },
            //   "generators": {
            //     "isUsedPeriod": false,
            //     "generatorTypes": [
            //       {
            //         "type": "naturalGas",
            //         "isActive": false,
            //         "costOfPeriod": 0
            //       }
            //     ]
            //   }
            // }

            // let userSelection = req.payload
            // if(userSelection.vehicles){
            //     emition.vehicles.isActive = true;
            //     emition.vehicles.status = "Active"
            // }
            // else{

            // }
            // added values
            // emition.userId = findUser._id;
            // create-user
            // emission data set
            emition.vehicleStatus = false;
            emition.buildingStatus = false;

            emition =  await emition.save();
            findUser = await findUser.save();
            return jsend(200, "Successfully Emission was Created ", emition);
        }
        catch(e){
            console.log(e);
            res.notAcceptaple(e)
        }
       
    }

     // find One ConFactVehicle
     async findOneEmissions(req, res) {
        try {

            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            let findemisson = await emissions.findOne({ _id: req.payload.emissionId });
            if (findemisson) {
                return jsend(200, "successfully fetched the Convetion Factors", findemisson);
            } else {
                return jsend(400, "Failed to fetched the Convetion Factors");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }
}

module.exports = Emission;