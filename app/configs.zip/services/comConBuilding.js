"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const comConBuildings = mongoose.model("comBuildingConvertion");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class ComConBuilding{
    async createcomConBuilding (req,res) {
        try{
            console.log(req.payload);
            let comConBuilding = new comConBuildings(req.payload);
            comConBuilding = await comConBuilding.save();
            return jsend(200, "Successfully Convetion Factors was Created ", comConBuilding);
        }
        catch(e){
            console.log(e);
            res.notAcceptaple(e);
        }
       
    }

     // find One ConFactVehicle
     async findOneConFactBuilding(req, res) {
        try {
            let findOneComBuilding = await comConBuildings.findOne({ _id: req.payload.id });
            if (findOneComBuilding) {
                return jsend(200, "successfully fetched the all User Profile", findOneComBuilding);
            } else {
                return jsend(400, "Failed to fetched the all User Profile");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // find All Vehicle Convertion Factors
    async findAllConFactBuilding(req, res) {
        try {
            // let obj = {}
            // if (req.payload.access) {
            //     obj.access = req.payload.access
            // }
            let findAllComBuilding = await comConBuildings.find({});
            if (findAllComBuilding) {
                return jsend(200, "successfully fetched the all User Profile", findAllComBuilding);
            } else {
                return jsend(400, "Failed to fetched the all User Profile");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

     // update user

     async updateConFactBuilding(req, res) {
        try {
            //    data pass of values
            let updateConFacBuilding = await comConBuildings.findOne({ _id: req.payload.id });
            if (updateConFacBuilding) {
                _.each(Object.keys(req.payload), (key) => {
                    updateConFacBuilding[key] = req.payload[key];
                });
                const result = await updateConFacBuilding.save();
                const updated = await comConBuildings.findOne({ _id: req.payload.id });
                return jsend(200, "Successfully Vehicles Convertion Factor details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the Vehicles Convertion Factor details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

     // delete user

     async deleteConFactBuilding(req, res) {
        try {
           
            // delete ConFactVehicle details
            let deleteConFactBuilding = await comConBuildings.findOne({ _id: req.payload.id });
            if (deleteConFactBuilding) {
                let deleteConFactBuildingDetailss = await comConBuildings.deleteOne({ _id: req.payload.id });
                return jsend(200, "Successfully User Profile was deleted");
            } else {
                return jsend(400, "Failed to deleted the User Profile");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }
}

module.exports = ComConBuilding;