"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const pvtEmission = mongoose.model("pvtemissions");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const pvtVehicles = mongoose.model("pvtVehicles");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class PvtVehicles {
    async pvtCreateVehicles(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let pvtEmision = await pvtEmission.findOne({ _id: req.payload.emissionId });
            console.log(pvtEmision);
            // fuels
            let pvtVehicle = new pvtVehicles(req.payload)
            // set of userId
            // pvtVehicle.userId = findUser._id

            // DATA FOR STORE OF DB
            pvtVehicle = await pvtVehicle.save();
            return jsend(200, "Successfully Vehicles was Created ", pvtVehicle);
        }
        catch (e) {
            console.log(e);
            res.notAcceptaple(e);
        }

    }

    // findone vehicles details
    // async findOneUserVehicles(req, res) {
    //     try {
    //         // token validation part
    //         const token = req.headers.authorization.split("Bearer ")[1];
    //         let findUser;
    //         // Authontification
    //         if (!token) {
    //             return jsend(406, "token is required");
    //         }
    //         var decoded = await jwt.verify(token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] })
    //         if (decoded) {
    //             findUser = await user.findOne({ _id: decoded._id });
    //             if (!findUser) {
    //                 return jsend(406, "Un-Authorized Access");
    //             }
    //         } else {
    //             return jsend(406, "Un-Authorized Access");
    //         }

    //         let findOneUsersVehicles = await vehicles.findOne({ _id: req.payload.id });
    //         if (findOneUsersVehicles) {
    //             return jsend(200, "successfully fetched the Particular Vehicle Profile", findOneUsersVehicles);
    //         } else {
    //             return jsend(400, "Failed to fetched the all Vehicle Profile");
    //         }

    //     }
    //     catch (e) {
    //         console.log(e);
    //         res.notAcceptable(e);
    //     }
    // }

    // find one user created vehicles list
    // async findOneUserAllVechicles(req, res) {
    //     try {
    //         // token validation part
    //         const token = req.headers.authorization.split("Bearer ")[1];
    //         let findUser;
    //         // Authontification
    //         if (!token) {
    //             return jsend(406, "token is required");
    //         }
    //         var decoded = await jwt.verify(token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] })
    //         if (decoded) {
    //             findUser = await user.findOne({ _id: decoded._id });
    //             if (!findUser) {
    //                 return jsend(406, "Un-Authorized Access");
    //             }
    //         } else {
    //             return jsend(406, "Un-Authorized Access");
    //         }

    //         let findOneUsersVehicles = await vehicles.find({ emissionId: req.payload.emissionId });
    //         if (findOneUsersVehicles) {
    //             return jsend(200, "successfully fetched the Particular User Profile", findOneUsersVehicles);
    //         } else {
    //             return jsend(400, "Failed to fetched the all User Profile");
    //         }

    //     }
    //     catch (e) {
    //         console.log(e);
    //         res.notAcceptable(e);
    //     }
    // }

    // UPDATE VEHICLE DETAILS

    async pvtUpdateVehicleDetails(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            console.log(decoded, "decoded");
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }


            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let pvtEmision = await pvtEmission.findOne({ _id: req.payload.emissionId });
            console.log(pvtEmision);


            //    data pass of values
            let pvtUpdateVehicles = await pvtVehicles.findOne({ _id: req.payload.pvtVehicleId });
            console.log(pvtUpdateVehicles);


            if (pvtUpdateVehicles) {
                _.each(Object.keys(req.payload), (key) => {
                    pvtUpdateVehicles[key] = req.payload[key];
                });

                let data = pvtUpdateVehicles;

                if (data.vehicleList.length <= 6) {
                    // Calculate total mileage
                    let totalMileage = 0;
                    for (const vehicle of data.vehicleList) {
                        for (const fuel of vehicle.fuels) {
                            if (fuel?.diesel) {
                                fuel.diesel.totalEmisson = fuel.diesel.milleage
                                totalMileage += fuel.diesel.milleage;
                            }
                            if (fuel?.bioPetrol) {
                                fuel.bioPetrol.totalEmisson = fuel.bioPetrol.milleage
                                totalMileage += fuel.bioPetrol.milleage;
                            }
                            if (fuel?.mineralPetrol) {
                                fuel.mineralPetrol.totalEmisson = fuel.mineralPetrol.milleage
                                totalMileage += fuel.mineralPetrol.milleage;
                            }
                            if (fuel?.hybrid) {
                                fuel.hybrid.totalEmisson = fuel.hybrid.milleage
                                totalMileage += fuel.hybrid.milleage;
                            }
                            // fuel.fuelsTotalEmisson = totalMileage;
                        }
                    }
                    // Calculate total liters of fuel oil used
                    if (data?.fuelOil) {
                        data.fuelOil.totalEmisson = data.fuelOil.litersOfPeriod
                    }
                    if (data?.lubricants) {
                        data.lubricants.totalEmisson = data.lubricants.litersOfPeriod
                    }
                    // Calculate total spent money on air condition
                    if (data?.airCondition) {
                        data.airCondition.totalEmisson = data.airCondition.spentMoney
                    }

                    // report generatior functions
                    if (pvtEmision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = true;
                        findUser.initialPayment = false;
                        // findUser.emissionStatus = {}
                    }
                    if (pvtEmision.buildings.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        findUser.initialPayment = true;
                    }
                    if (pvtEmision.buildings.isActive && pvtEmision.vehicles.isActive) {
                        // userReporting generations functionality
                        findUser.reportingStatus = false;
                        findUser.initialPayment = true;
                    }


                    const result = await pvtUpdateVehicles.save();
                    findUser = await findUser.save();
                    const updated = await pvtVehicles.findOne({ _id: req.payload.pvtVehicleId });
                    return jsend(200, "Successfully Vehicle details was Updated", updated);
                }
                else {
                    return jsend(400, "Maxmum Allowed 6 Cars Only")
                }

            } else {
                return jsend(400, "failed to Updated the Vehicle details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

}

module.exports = PvtVehicles;