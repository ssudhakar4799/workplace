"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const bulding = mongoose.model("building");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");
const emission = mongoose.model("emissions");
const conBuilding = mongoose.model("comBuildingConvertion");

class Building {

    async createBuilding(req, res) {
        try {

           
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let emision = await emission.findOne({ _id: req.payload.emissionId })
            console.log(emision);

            let buildings = new bulding(req.payload);
            // console.log(buildings);



            buildings = await buildings.save();
            return jsend(200,"successfully enter in to the create Building pages", buildings)

        }
        catch (error) {
            console.log(error);
            res.notAcceptable(error)

        }
    }

    // UPDATE BUILDING DETAILS

    async updateBuildingDetails(req, res) {
        try {
            // token validation part
            let findUser;
            // Authontification
            if (!req.query.token) {
                return jsend(406, "token is required");
            }
            var decoded = await jwt.verify(req.query.token, process.env.JWT_SECRET_KEY, { algorithms: ['HS256'] });
            if (decoded) {
                findUser = await user.findOne({ _id: decoded._id });
                console.log(findUser, "findUser");
                if (!findUser) {
                    return jsend(406, "Un-Authorized Access");
                }
            } else {
                return jsend(406, "Un-Authorized Access");
            }

            //    data pass of values
            let updateBulding = await bulding.findOne({ _id: req.payload.buildingId });

            // USER SELECTION OF CHECK FOR VEHICLES OR 
            let emision = await emission.findOne({ _id: req.payload.emissionId });
            console.log(emision);

            // CONVERTION FACTORS DETAILS 
            let conFactBuilding = await conBuilding.find({});
            //  console.log(conFactBuilding);
            //  latest update details
            let latestDetails = conFactBuilding[conFactBuilding.length - 1];
            console.log(latestDetails);

            if (updateBulding) {
                _.each(Object.keys(req.payload), (key) => {
                    updateBulding[key] = req.payload[key];
                });

                // Building calculation of convertion Factors STARTING 

                let object = updateBulding;

                function calculateCostOfPeriod(data) {
                    let totalCost = 0;
                    let electricityTotalEmissions;
                    let gasTotalEmissions;
                    let oilTotalEmissions;
                    let lpgTotalEmissions;
                    let biofuelsTotalEmissions;
                    let coalTotalEmissions;
                    let coolingCostTotalEmissions;

                    // Electricity cost.
                    if (data.electricity?.isUsedPeriod) {
                        // // price
                        // let price=latestDetails;
                        // // let co2 = latestDetails.
                        // let Co2 = data.electricity.milleage * latestDetails.electricity.Co2e_of_Co2_unit
                        // let Ch4 = data.electricity.milleage * latestDetails.electricity.Co2e_of_Ch4_unit
                        // let N2O = data.electricity.milleage * latestDetails.electricity.Co2e_of_N2O_unit
                        // // electricity total emisssion
                        electricityTotalEmissions = data.electricity.costOfPeriod / 0.34 * 0.207074;
                        data.electricity.electricityTotalEmission = electricityTotalEmissions;
                        // completed status add step
                        data.electricity.isComplete = true;
                        // all total emissions
                        totalCost += electricityTotalEmissions

                    }

                    // Heating cost.
                    for (const heatedType of data.heatingUp.heatedTypes) {
                        if (heatedType.type == "gas") {
                            // gas total emissions
                            gasTotalEmissions = heatedType.costOfPeriod / 7.51 * 0.2;
                            heatedType.totalEmission = gasTotalEmissions;
                            // completed status add step
                            heatedType.isComplete = true;
                            // all total emissions
                            totalCost += gasTotalEmissions;
                        }
                        if (heatedType.type == "oil") {
                            // oil total emissions
                            oilTotalEmissions = heatedType.costOfPeriod / 1.02 * 2.76;
                            heatedType.totalEmission = oilTotalEmissions;
                            // completed status add step
                            heatedType.isComplete = true;
                            // all total emissions
                            totalCost += oilTotalEmissions;
                        }
                        if (heatedType.type == "lpg") {
                            // lpg total emissions
                            lpgTotalEmissions = heatedType.costOfPeriod / 0.77 * 1.17;
                            heatedType.totalEmission = lpgTotalEmissions;
                            // completed status add step
                            heatedType.isComplete = true;
                            // all total emissions
                            totalCost += lpgTotalEmissions;
                        }
                        if (heatedType.type == "bioFuel") {
                            // biofuel total emissions
                            biofuelsTotalEmissions = heatedType.costOfPeriod / 2.35 * 0.35;
                            heatedType.totalEmission = biofuelsTotalEmissions;
                            // completed status add step
                            heatedType.isComplete = true;
                            // all total emissions
                            totalCost += biofuelsTotalEmissions;
                        }
                        if (heatedType.type == "coal") {
                            // coal total emissions
                            coalTotalEmissions = heatedType.costOfPeriod / 0.5 * 0.32;
                            heatedType.totalEmission = coalTotalEmissions;
                            // completed status add step
                            heatedType.isComplete = true;
                            // all total emissions
                            totalCost += coalTotalEmissions;
                        }
                    }

                    // Cooling cost.
                    if (data.coolingDown.isUsedPeriod) {
                        // cost total emissions
                        coolingCostTotalEmissions = data.coolingDown.costOfPeriod / 13.1 * 1300;
                        data.coolingDown.coolingDownTotalEmssion = coolingCostTotalEmissions;
                        // completed status add step
                        data.coolingDown.isComplete = true;
                        // all total emissions
                        totalCost += coolingCostTotalEmissions
                    }

                    // Generatior calculations
                    let naturalGasTotalEmission;
                    let gasOilTotalEmission;
                    let dieselTotalEmissions;
                    let propaneTotalEmissions;
                    let petrolTotalEmissions;
                    let gasOilTotalEmissions;

                    // Generator cost.
                    for (const generatorType of data.generators.generatorTypes) {
                        if (generatorType.type == "naturalGas") {
                            // naturalGas total emissions
                            naturalGasTotalEmission = generatorType.costOfPeriod / 7.51 * 2.02;
                            generatorType.totalEmission = naturalGasTotalEmission;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += naturalGasTotalEmission;
                        }
                        if (generatorType.type == "gasOil") {
                            // diesel total emissions
                            gasOilTotalEmission = generatorType.costOfPeriod / 1 * 2.53;
                            generatorType.totalEmission = gasOilTotalEmission;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += gasOilTotalEmission;
                        }
                        if (generatorType.type == "diesel") {
                            // diesel total emissions
                            dieselTotalEmissions = generatorType.costOfPeriod / 1 * 2.53;
                            generatorType.totalEmission = dieselTotalEmissions;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += dieselTotalEmissions;
                        }
                        if (generatorType.type == "propane") {
                            // propane total emissions
                            propaneTotalEmissions = generatorType.costOfPeriod / 1 * 1.54;                    
                            generatorType.totalEmission = propaneTotalEmissions;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += propaneTotalEmissions;
                        }
                        if (generatorType.type == "petrol") {
                            // petrol total emissions
                            petrolTotalEmissions = generatorType.costOfPeriod / 1 * 2.1;
                            generatorType.totalEmission = petrolTotalEmissions;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += petrolTotalEmissions;
                        }
                        if (generatorType.type == "gasOil") {
                            // petrol total emissions
                            gasOilTotalEmissions = generatorType.costOfPeriod / 1 * 2.1;
                            generatorType.totalEmission = gasOilTotalEmissions;
                            // completed status add step
                            generatorType.isComplete = true;
                            // all total emissions
                            totalCost += gasOilTotalEmissions;
                            emision.buildingSchema.completedStatus = true;
                        }
                    }

                    return totalCost;
                }

                const totalCost = calculateCostOfPeriod(object);

                // set of building total emissions
                updateBulding.buildingTotalEmissions = totalCost;

                console.log(totalCost); // 150

                console.log(updateBulding);

                // userReporting generations functionality
                if(findUser.paymentType == "oneTimePayment"){
                    findUser.reportingStatus = true;
                    findUser.initialPayment = false;
                }
                else if(findUser.paymentType == "monthlySubscribers"){
                    findUser.reportingStatus = true;
                }
                // Building calculation of convertion Factors ENDING
                const emistionDatas= await emision.save();
                const result = await updateBulding.save();
                findUser = await findUser.save();
                const updated = await bulding.findOne({ _id: req.payload.buildingId });
                return jsend(200, "Successfully Building details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the Building details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

}
module.exports = Building