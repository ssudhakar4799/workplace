"use strict";
const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const subscription = mongoose.model("subscription");
const jsend = serviceLocator.get("jsend");
const _ = serviceLocator.get("_");
const comConVehicles = mongoose.model("commercialVehicleConverion");
const jwt = serviceLocator.get("jwt");
const moment = serviceLocator.get("moment");
const user = mongoose.model("user");


class ComConVehicles {
    async createcomConVehicle(req, res) {
        try {
            let comConVehicle = new comConVehicles(req.payload);
            comConVehicle = await comConVehicle.save();
            return jsend(200, "Successfully Convetion Factors was Created ", comConVehicle);
        }
        catch (e) {
            console.log(e);
            res.notAcceptaple(e)
        }

    }

    // find One ConFactVehicle
    async findOneConFactVehicle(req, res) {
        try {
            let findOneComVehicle = await comConVehicles.findOne({ _id: req.payload.id });
            if (findOneComVehicle) {
                return jsend(200, "successfully fetched the Convetion Factors", findOneComVehicle);
            } else {
                return jsend(400, "Failed to fetched the Convetion Factors");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // find All Vehicle Convertion Factors
    async findAllConFactVehicle(req, res) {
        try {
            // let obj = {}
            // if (req.payload.access) {
            //     obj.access = req.payload.access
            // }
            let findAllComVehicle = await comConVehicles.find({});
            if (findAllComVehicle) {
                return jsend(200, "successfully fetched the Convetion Factors", findAllComVehicle);
            } else {
                return jsend(400, "Failed to fetched the Convetion Factors");
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

    // update user

    async updateConFactVehicle(req, res) {
        try {
            //    data pass of values
            let updateConFacVehicle = await comConVehicles.findOne({ _id: req.payload.id });
            if (updateConFacVehicle) {
                _.each(Object.keys(req.payload), (key) => {
                    updateConFacVehicle[key] = req.payload[key];
                });
                const result = await updateConFacVehicle.save();
                const updated = await comConVehicles.findOne({ _id: req.payload.id });
                return jsend(200, "Successfully Vehicles Convertion Factor details was Updated", updated);
            } else {
                return jsend(400, "failed to Updated the Vehicles Convertion Factor details ")
            }

        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e)
        }
    }

    // delete user

    async deleteConFactVehicle(req, res) {
        try {

            // delete ConFactVehicle details
            let deleteConFactVehicle = await comConVehicles.findOne({ _id: req.payload.id });
            if (deleteConFactVehicle) {
                let deleteConFactVehicleDetailss = await comConVehicles.deleteOne({ _id: req.payload.id });
                return jsend(200, "Successfully Convetion Factors was deleted");
            } else {
                return jsend(400, "Failed to deleted the Convetion Factors");
            }
        }
        catch (e) {
            console.log(e);
            res.notAcceptable(e);
        }
    }

}

module.exports = ComConVehicles;