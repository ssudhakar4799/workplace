"use strict";

const serviceLocator = require("../lib/service_locator");
const config = require("./configs")();


serviceLocator.register("logger", () => {
  return require("../lib/logger").create(config.application_logging);
});

serviceLocator.register("joi", () => {
  return require("joi");
});

serviceLocator.register("otpgenerator", () => {
  return require("otp-generator");
});


serviceLocator.register("jsend", () => {
  return require("../lib/jsend");
});

serviceLocator.register("failAction", () => {
  return require("../lib/failAction").verify;
});

serviceLocator.register("trimRequest", () => {
  return require("../utils/trimRequest").all;
});

serviceLocator.register("mongoose", () => {
  return require("mongoose");
});

serviceLocator.register("bcrypt", () => {
  return require("bcrypt");
});

serviceLocator.register("fs", () => {
  return require("fs");
});

serviceLocator.register("path", () => {
  return require("path");
});

serviceLocator.register("nodemailer", () => {
  return require("nodemailer");
});

serviceLocator.register("jwt", () => {
  return require("jsonwebtoken");
});

serviceLocator.register("moment", () => {
  return require("moment");
});


serviceLocator.register("_", () => {
  return require("underscore");
});

serviceLocator.register("glob", () => {
  return require("glob");
});


serviceLocator.register("Subscription", (serviceLocator) => {

  const Subscription = require("../services/commercialSubscription");

  return new Subscription();

});

serviceLocator.register("User", (serviceLocator) => {

  const User = require("../services/user");

  return new User();

});

serviceLocator.register("Emission", (serviceLocator) => {

  const  Emission= require("../services/commercialEmission");

  return new Emission();

});

serviceLocator.register("Vehicle", (serviceLocator) => {

  const  Vehicle= require("../services/commercialVehicles");

  return new Vehicle();

});

serviceLocator.register("Bulding", (serviceLocator) => {

  const  Bulding= require("../services/commercialBuilding");

  return new Bulding();

});

// private pages

serviceLocator.register("PvtSubsctiptions", (serviceLocator) => {

  const  PvtSubsctiptions= require("../services/privateSubscription");

  return new PvtSubsctiptions();

});

serviceLocator.register("PvtEmission", (serviceLocator) => {

  const  PvtEmission= require("../services/privateEmissions");

  return new PvtEmission();

});

serviceLocator.register("PvtVehicle", (serviceLocator) => {

  const  PvtVehicle= require("../services/privateVehicles");

  return new PvtVehicle();

});

serviceLocator.register("PvtBuilding", (serviceLocator) => {

  const  PvtBuilding= require("../services/privateBuilding");

  return new PvtBuilding();

});

serviceLocator.register("ComConVehicle", (serviceLocator) => {

  const  ComConVehicle= require("../services/comConVehicle");

  return new ComConVehicle();

});

serviceLocator.register("ComConBuilding", (serviceLocator) => {

  const  ComConBuilding = require("../services/comConBuilding");

  return new ComConBuilding();

});

serviceLocator.register("PvtConVehicle", (serviceLocator) => {

  const  PvtConVehicle = require("../services/privateConFacVehicle");

  return new PvtConVehicle();

});

serviceLocator.register("PvtConBuilding", (serviceLocator) => {

  const  PvtConBuilding = require("../services/privateConFacBuilding");

  return new PvtConBuilding();

});

module.exports = serviceLocator;
