"use strict";

const serviceLocator = require("../lib/service_locator");
const failAction = serviceLocator.get("failAction");
const trimRequest = serviceLocator.get("trimRequest");
const subscription = serviceLocator.get("Subscription");

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createSubscription",
            method: "POST",
            handler: subscription.createSubscription,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/subscripton/subscriptionValidation'),
                    failAction: failAction
                }
            },
        }
    ]);


};