"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const vehicles = serviceLocator.get("Vehicle")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createVehicles",
            method: "POST",
            handler: vehicles.createVehicles,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/vehicles/createVehiclesValidations'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findOneUserVehicles",
            method: "POST",
            handler: vehicles.findOneUserVehicles,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/vehicles/findOneValidations'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findOneUserAllVechicles",
            method: "POST",
            handler: vehicles.findOneUserAllVechicles,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/vehicles/findAllVehicleValidations'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/updateVehicleDetails",
            method: "POST",
            handler: vehicles.updateVehicleDetails,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/vehicles/updateVehiclesValidation'),
                    failAction: failAction
                }
            },
        }
    ]);


};