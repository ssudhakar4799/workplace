"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const user = serviceLocator.get("User");

exports.routes = (server, serviceLocator) => {
    return server.route([
        {

            path: "/LightHouse/createUserProflie",
            method: "POST",
            handler: user.createUserProflie,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/createUserVaildation'),
                    failAction: failAction
                }
            },
        },
        {

            path: "/LightHouse/updateUser",
            method: "POST",
            handler: user.updateUser,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/updateUserVaildation'),
                    failAction: failAction
                }
            },
        },
        {

            path: "/LightHouse/deletUser",
            method: "DELETE",
            handler: user.deleteUser,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/deleteUserVaildation'),
                    failAction: failAction
                }
            },

        },
        {

            path: "/LightHouse/findOneUser",
            method: "POST",
            handler: user.findOneUser,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/findOneUserDetails'),
                    failAction: failAction
                }
            },

        },
        {

            path: "/LightHouse/findAllUser",
            method: "POST",
            handler: user.findAllUser,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/findAllUserDetails'),
                    failAction: failAction
                }
            },

        },
        {

            path: "/LightHouse/loginDetails",
            method: "POST",
            handler: user.loginDetails,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/loginDetails'),
                    failAction: failAction
                }
            },

        },
        {
            path:"/LightHouse/generatorOTP",
            method:"POST",
            handler:user.generatorOTP,
            options:{
                auth:false,
                validate:{
                    payload:require("../validations/user/forgetpasswordVaildation"),
                    failAction:failAction
                }
            }
        },
        {
            path: "/LightHouse/verifyOtp",
            method: "post",
            handler: user.verifyOtp,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/verifyotyuserVaildation'),
                    failAction: failAction
                }
            },

        },
        {

            path: "/LightHouse/genNewPassword",
            method: "post",
            handler: user.genNewPassword,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/user/genNewpasswordVaildation'),
                    failAction: failAction
                }
            },

        },
        
    ]);

};