"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const pvtConBuilding = serviceLocator.get("PvtConBuilding")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtCreatecomConBuilding",
            method: "POST",
            handler:pvtConBuilding.pvtCreatecomConBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/pvtConFacBuilding/createPvtBuilding'),
                    failAction: failAction
                }
            },
        }
    ]);


};