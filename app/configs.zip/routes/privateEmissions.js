"use strict";

const serviceLocator = require("../lib/service_locator");
const failAction = serviceLocator.get("failAction");
const trimRequest = serviceLocator.get("trimRequest");
const pvtEmission = serviceLocator.get("PvtEmission");

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtcreateEmission",
            method: "POST",
            handler: pvtEmission.pvtcreateEmission,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/emissions/pvtCreateEmissionsValidations'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/pvtUpdateEmissions",
            method: "POST",
            handler: pvtEmission.pvtUpdateEmissions,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/emissions/pvtUpdateEmissionValidation'),
                    failAction: failAction
                }
            },
        }
    ]);


};