"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const pvtConVehicle = serviceLocator.get("PvtConVehicle")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtCreatecomConVehicle",
            method: "POST",
            handler:pvtConVehicle.pvtCreatecomConVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/pvtConFacVehicle/createPvtConFacValidations'),
                    failAction: failAction
                }
            },
        }
    ]);


};