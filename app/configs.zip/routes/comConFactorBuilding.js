"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const comConBuilding = serviceLocator.get("ComConBuilding")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createcomConBuilding",
            method: "POST",
            handler:comConBuilding.createcomConBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/conFacBuilding/crtConFacBuilding'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findOneConFactBuilding",
            method: "POST",
            handler:comConBuilding.findOneConFactBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/conFacBuilding/findOneConBuilding'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findAllConFactBuilding",
            method: "POST",
            handler:comConBuilding.findAllConFactBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/conFacBuilding/findAllConBuilding'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/updateConFactBuilding",
            method: "POST",
            handler:comConBuilding.updateConFactBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/conFacBuilding/updateConBuilding'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/deleteConFactBuilding",
            method: "DELETE",
            handler:comConBuilding.deleteConFactBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/conFacBuilding/deleteConBuilding'),
                    failAction: failAction
                }
            },
        }
    ]);


};