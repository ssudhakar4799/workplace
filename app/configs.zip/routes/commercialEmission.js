"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const emission = serviceLocator.get("Emission")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createEmission",
            method: "POST",
            handler: emission.createEmission,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/emission/createEmissionValidation'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findOneEmissions",
            method: "POST",
            handler: emission.findOneEmissions,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/emission/findOneEmission'),
                    failAction: failAction
                }
            },
        }
    ]);


};