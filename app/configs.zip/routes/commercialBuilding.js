"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const building = serviceLocator.get("Bulding")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createBuilding",
            method: "POST",
            handler:building.createBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/building/createBuildingValidations'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/updateBuildingDetails",
            method: "POST",
            handler:building.updateBuildingDetails,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/building/updateBuildingValidations'),
                    failAction: failAction
                }
            },
        }
    ]);


};