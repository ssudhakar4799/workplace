"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const pvtVehicles = serviceLocator.get("PvtVehicle")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtCreateVehicles",
            method: "POST",
            handler: pvtVehicles.pvtCreateVehicles,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/vehicles/pvtCreateVehiclesValidations'),
                    failAction: failAction
                }
            },
        },
        // {
        //     path: "/LightHouse/findOneUserVehicles",
        //     method: "POST",
        //     handler: vehicles.findOneUserVehicles,
        //     options: {
        //         auth: false,
        //         validate: {
        //             payload: require('../validations/commercial/vehicles/findOneValidations'),
        //             failAction: failAction
        //         }
        //     },
        // },
        // {
        //     path: "/LightHouse/findOneUserAllVechicles",
        //     method: "POST",
        //     handler: vehicles.findOneUserAllVechicles,
        //     options: {
        //         auth: false,
        //         validate: {
        //             payload: require('../validations/commercial/vehicles/findAllVehicleValidations'),
        //             failAction: failAction
        //         }
        //     },
        // },
        {
            path: "/LightHouse/pvtUpdateVehicleDetails",
            method: "POST",
            handler: pvtVehicles.pvtUpdateVehicleDetails,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/vehicles/pvtUpdateVehiclesValidations'),
                    failAction: failAction
                }
            },
        }
    ]);


};