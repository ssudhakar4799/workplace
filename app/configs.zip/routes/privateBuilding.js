"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const pvtBuilding = serviceLocator.get("PvtBuilding")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtCreateBuilding",
            method: "POST",
            handler:pvtBuilding.pvtCreateBuilding,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/buildings/pvtCreateBuildingValidation'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/pvtUpdateBuildingDetails",
            method: "POST",
            handler:pvtBuilding.pvtUpdateBuildingDetails,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/buildings/pvtUpdateBuildingValidations'),
                    failAction: failAction
                }
            },
        }
    ]);


};