"use strict";

const serviceLocator = require("../lib/service_locator");
const failAction = serviceLocator.get("failAction");
const trimRequest = serviceLocator.get("trimRequest");
const pvtsubscription = serviceLocator.get("PvtSubsctiptions");

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/pvtcreateSubscription",
            method: "POST",
            handler: pvtsubscription.pvtcreateSubscription,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/private/subscription/pvtCreateSubscriptionValidation'),
                    failAction: failAction
                }
            },
        }
    ]);


};