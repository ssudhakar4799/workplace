"use strict";

const serviceLocator = require("../lib/service_locator");
const trimRequest = serviceLocator.get("trimRequest");
const failAction = serviceLocator.get("failAction");
const comConVehicle = serviceLocator.get("ComConVehicle")

exports.routes = (server, serviceLocator) => {
    return server.route([
        {
            path: "/LightHouse/createcomConVehicle",
            method: "POST",
            handler:comConVehicle.createcomConVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/convetionFactor/createComConVehicle'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findOneConFactVehicle",
            method: "POST",
            handler:comConVehicle.findOneConFactVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/convetionFactor/findOneVehicleValidation'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/findAllConFactVehicle",
            method: "POST",
            handler:comConVehicle.findAllConFactVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/convetionFactor/findAllConVehicles'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/updateConFactVehicle",
            method: "POST",
            handler:comConVehicle.updateConFactVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/convetionFactor/updateConFacVehicles'),
                    failAction: failAction
                }
            },
        },
        {
            path: "/LightHouse/deleteConFactVehicle",
            method: "DELETE",
            handler:comConVehicle.deleteConFactVehicle,
            options: {
                auth: false,
                validate: {
                    payload: require('../validations/commercial/convetionFactor/deleteConFacVehicles'),
                    failAction: failAction
                }
            },
        }
    ]);


};