"use strict";

const serviceLocator = require("../../../lib/service_locator");
const joi = serviceLocator.get("joi");
module.exports = joi.object({
    emissionId:joi.string().optional(),
    userId: joi.string().optional(),
    periodFrom: joi.date().optional(),
    periodTo: joi.date().optional(),
    reports:joi.object().optional(),
    vehicles: joi.object().optional(),
    buildings: joi.object().optional()
});