"use strict";

const serviceLocator = require("../../../lib/service_locator");
const joi = serviceLocator.get("joi");

module.exports = joi.object({
    pvtVehicleId:joi.string().required(),
    userId: joi.string().optional(),
    emissionId: joi.string().required(),
    vehiclesList:joi.number().required(),
    vehicleList: joi.array().optional(),
    fuelOil: joi.object().optional(),
    lubricants: joi.object().optional(),
    airCondition: joi.object().optional()
});