"use strict";

const serviceLocator = require("../../../lib/service_locator");
const joi = serviceLocator.get("joi");

module.exports = joi.object({
    userId: joi.string().required(),
    emissionId: joi.string().required(),
    vehiclesList:joi.number().required(),
    vehicleList: joi.array().optional(),
    fuelOil: joi.object().optional(),
    lubricants: joi.object().optional(),
    airCondition: joi.object().optional()
});