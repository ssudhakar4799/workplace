"use strict";

const serviceLocator = require("../../../lib/service_locator");
const joi = serviceLocator.get("joi");
module.exports = joi.object({
    buildingId:joi.string().required(),
    emissionId: joi.string().required(),
    electricity: joi.object().optional(),
    heatingUp: joi.object().optional(),
    coolingDown: joi.object().optional(),
    generators: joi.object().optional(),

});