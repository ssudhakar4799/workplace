"use strict";

const serviceLocator = require("../../../lib/service_locator");
const joi = serviceLocator.get("joi");

module.exports = joi.object({
    // userId: joi.string().optional(),
    // emissionId: joi.string().required(),
    fuels: joi.object().optional(),
    fuelOil: joi.object().optional(),
    lubricants: joi.object().optional(),
    airCondition: joi.object().optional(),
    trailerRefrigeration:joi.object().optional()
});