"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const vehicleSchema = mongoose.Schema({
    isActive: Boolean,
    status: String
});

const buildingSchema = mongoose.Schema({
    isActive: Boolean,
    status: String
});

const emissionSchema = mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    periodFrom: {
        type: Date,
        required: [true, "Set PeriodFrom Date"]
    },
    periodTo: {
        type: Date,
        required: [true, "Set PeriodTo Date"]
    },
    vehicles: vehicleSchema,
    buildings: buildingSchema,
    vehicleStatus:Boolean,
    buildingStatus:Boolean,
    vehicleStructure:{
        type:Object,
        required:false
    },
    buildingStructure:{
        type:Object,
        required:false
    }
},
    {
        timestamps: true
    });

module.exports = mongoose.model("emissions", emissionSchema, "emissions");


