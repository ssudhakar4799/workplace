"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");


var privateSubscriptionSchema = mongoose.Schema(
    {
        userId: {
            type: String,
            require: true
        },
        userType: {
            isPrivate: {
                type: Boolean,
                require: false
            },
            isCommercial: {
                type: Boolean,
                require: false
            }
        },
        paymentType: {
            oneTimePayment: {
                isActive: Boolean,
                payDate: {
                    type: Date,
                    required: true
                },
                expiredDate: {
                    type: Date,
                    required: true
                },
                amount: {
                    type: Number,
                    required: true
                }
            }
        }
    },
    {
        timestamps: true,
    }
);
module.exports = mongoose.model("pvtSubscription",privateSubscriptionSchema,"pvtSubscription");
