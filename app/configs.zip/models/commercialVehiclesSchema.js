"use strict"

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");


const fuelSchema = mongoose.Schema({
    bioPetrol: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        bioPetrolEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    mineralPetrol: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        mineralPetrolEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    diesel: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        dieselEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    lpg: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        lpgEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    lng: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        lncEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    cng: {
        isUsedPeriod: Boolean,
        milleage:{
            type:Number,
            required:false
        },
        cngEmission:{
            type:Number,
            required:false
        },
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    fuelTotalEmission:{
        type:Number,
        required:false
    },
    fuelsStatus:{
        type:String,
        required:false
    }
  });
  
  const fuelOilSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    litersOfPeriod: Number,
    fuelOilEmission:Number,
    isComplete:{
        type:Boolean,
        required:false
    }
  });
  
  const vehiclesSchema = mongoose.Schema({
    emissionId: String,
    userId: String,
    fuels: fuelSchema,
    fuelOil: fuelOilSchema,
    lubricants: {
      isUsedPeriod: Boolean,
      litersOfPeriod: Number,
      lubricantsEmission:Number,
      isComplete:{
          type:Boolean,
          required:false
      },
      required:false
    },
    trailerRefrigeration: {
      isUsedPeriod: Boolean,
      spentMoney: Number,
      trailerRefrigerationEmission:Number,
      isComplete:{
          type:Boolean,
          required:false
      },
      required:false
    },
    airCondition: {
      isUsedPeriod: Boolean,
      spentMoney: Number,
      airConditionEmission:Number,
      isComplete:{
          type:Boolean,
          required:false
      },
      required:false
    },
    vehiclesTotalEmission:{
        type:Number,
        required:false
    },
    Co2totalEmission:{
        type:Number,
        required:false
    },
    Ch4totalEmission:{
        type:Number,
        required:false
    },
    N2OtotalEmission:{
        type:Number,
        required:false
    },
    vehicleStatus:{
        type:String,
        required:false
    }
  },
  {
    timestamps:true
  }
  );

module.exports = mongoose.model("vehicles",vehiclesSchema,"vehicles")