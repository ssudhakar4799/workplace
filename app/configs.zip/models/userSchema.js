"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
const {validateEmail,validatePassword} = require("../utils/validate") 

var userSchema = new mongoose.Schema(
    {
        // type:{
        //     type:String,
        //     required:true
        // },
        email: {
            type: String,
            required: [true, "Please enter your email"],
            unique: true,
            validate:validateEmail,
        },
        password: {
            type: String,
            required: [true, "Please enter your password"]
        },
        companyName:{
            type:String,
            required:[true,"Please enter your companyName"]
        },
        countryCode: {
            type: String,
            required: [true, "Please Select Your Country Code"]
        },
        postalCode:{
            type:String,
            required:[true,"Please enter your postalCode"]
        },
        city:{
            type:String,
            required:[true,"Please enter your city"]
        },
        address:{
            type:String,
            required:[true,"Please enter your address"]
        },
        token: {
            type: String,
            required: false,
        },
        expiredDate: {
            type: Date,
            required: false,
        },
        initialPayment:{
            type:Boolean,
            required:false
        },
        reportingStatus:{
            type:Boolean,
            required:false
        },
        userType:{
            type:String,
            required:true
        },
        emissionStatus:{
            pendingStatus:{
                type:Boolean,
                required:false
            },
            emissionId:{
                type:String,
                required:false
            },
            emissionsDetails:{
                type:Object,
                required:false
            },

        },
        paymentType:{
            type:String,
            required:false
        },
        createVehicleDetails:{
            type:Object,
            required:false
        },
        createBuilding:{
            type:Object,
            required:false
        },
        previousEmission:{
            type:String,
            required:false
        },
        resumeEmission:{
            type:String,
            required:false
        }
    }, {
        timestamps: true
    }
);
module.exports = mongoose.model("user", userSchema, "user");