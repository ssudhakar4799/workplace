"use strict"

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const pvtBuildingConvertionSchema = mongoose.Schema({
    electricity: {
        price: {
            type: Number,
            required: false
        },
        Co2e_of_Co2_unit: {
            type: Number,
            required: false
        },
        Co2e_of_Ch4_unit: {
            type: Number,
            required: false
        },
        Co2e_of_N2O_unit: {
            type: Number,
            required: false
        }
    },
    coolingDown: {
        price: {
            type: Number,
            required: false
        },
        Co2e_unit: {
            type: Number,
            required: false
        }
    },
    heatingUp: {
        gas: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        oil: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        lpg: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        bioFuel: {
            price: {
                type: Number,
                required: false
            },
            Co2e_unit: {
                type: Number,
                required: false
            }
        },
        coal: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        }
    },
    generators: {
        naturalGas: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        diesel: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        propane: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        petrol: {
            price: {
                type: Number,
                required: false
            },
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        }
    }

})
module.exports = mongoose.model("pvtBuildingConvertion", pvtBuildingConvertionSchema, "pvtBuildingConvertion")