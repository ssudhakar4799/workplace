"use strict"

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const bioPetrolSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    milleage: Number,
    vehicleSize: String,
    totalEmisson: Number
});

const mineralPetrolSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    milleage: Number,
    vehicleSize: String,
    totalEmisson: Number
});
const dieselSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    milleage: Number,
    vehicleSize: String,
    totalEmisson: Number
});

const hybridSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    milleage: Number,
    vehicleSize: String,
    totalEmisson: Number
});
const fuelSchema = mongoose.Schema({
    bioPetrol: bioPetrolSchema,
    mineralPetrol: mineralPetrolSchema,
    diesel:dieselSchema,
    hybrid:hybridSchema
    // fuelsTotalEmisson:Number
});

const vehicleListSchema = mongoose.Schema({
    title: String,
    fuels: [fuelSchema],
    vehicleTotalEmission:Number
});

const fuelOilSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    litersOfPeriod: Number,
    totalEmisson : Number
});

const lubricantsSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    litersOfPeriod: Number,
    totalEmisson : Number
});

const airConditionSchema = mongoose.Schema({
    isUsedPeriod: Boolean,
    spentMoney: Number,
    totalEmisson : Number
});

const pvtVehiclesSchema = mongoose.Schema({
    emissionId: String,
    userId: String,
    vehiclesList: Number,
    vehicleList: [vehicleListSchema],
    fuelOil: fuelOilSchema,
    lubricants: lubricantsSchema,
    airCondition: airConditionSchema,
    pvtTotalEmissions:Number
});

module.exports = mongoose.model("pvtVehicles", pvtVehiclesSchema, "pvtVehicles")