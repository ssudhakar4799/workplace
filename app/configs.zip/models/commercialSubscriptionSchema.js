"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");
// const mongoose = require("mongoose")

// const user = require("../services/user")

var SubscriptionSchema = mongoose.Schema(
    {
        userId: {
            type: String,
            require: true
        },
        userType:{
            isPrivate:{
                type:Boolean,
                require:false
            },
            isCommercial:{
                type:Boolean,
                require:false
            }
        },
        // private:{
        //     isActive:{
        //         type:String,
        //         required:false
        //     },
        //     payment:{
        //         yearlyPayments:{
        //             type:Number,
        //             required:true
        //         },
        //         payDate:{
        //             type:Date,
        //             required:true
        //         },
        //         expiredDate:{
        //             type:Date,
        //             required:true
        //         }
        //     }
        // },
        // commercial:{
        //     isActive:{
        //         type:String,
        //         required:false
        //     },
        //     payments:{
        //         monthlyPayments:{
        //             type:Number,
        //             required:true
        //         },
        //         yearlyPayments:{
        //             type:Number,
        //             required:false
        //         },
        //         payDate:{
        //             type:Date,
        //             required:true
        //         },
        //         expiredDate:{
        //             type:Date,
        //             required:true
        //         }
        //     }
        // }
        paymentType: {
            oneTimePayment: {
                isActive: Boolean,
                payDate: {
                    type: Date,
                    required: false
                },
                expiredDate: {
                    type: Date,
                    required: false
                },
                amount: {
                    type: Number,
                    required: false
                }
            },
            monthlySubscriber: {
                isActive: Boolean,
                payDate: {
                    type: Date,
                    required: false
                },
                expiredDate: {
                    type: Date,
                    required: false
                },
                amount: {
                    type: Number,
                    required: false
                }
            }
        }
    },
    {
        timestamps: true,
    }

);
module.exports = mongoose.model("subscription", SubscriptionSchema, "subscription");