"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const vehicleSchema = mongoose.Schema({
    isActive: Boolean,
    status: String
});

const buildingSchema = mongoose.Schema({
    isActive: Boolean,
    status: String
});

const PvtemissionSchema = mongoose.Schema({
    userId: {
        type: String,
        required: true
    },
    periodFrom: {
        type: Date,
        required: [true, "Set PeriodFrom Date"]
    },
    periodTo: {
        type: Date,
        required: [true, "Set PeriodTo Date"]
    },
    vehicles: vehicleSchema,
    buildings: buildingSchema,
    reports:{
        individual:{
            isActive:Boolean,
            required:false,
            adults:{
                type:Number,
                required:true
            }
        },
        houseHold:{
            isActive:Boolean,
            type:String,
            required:false
        }
    }
},
    {
        timestamps: true
    });

module.exports = mongoose.model("pvtemissions", PvtemissionSchema, "pvtemissions");


