"use strict";

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const heatingTypeSchema = mongoose.Schema({
    type: String,
    isActive: Boolean,
    costOfPeriod: Number,
    totalEmission:Number,
    isComplete:{
        type:Boolean,
        required:false
    }
});

const generatorTypeSchema = mongoose.Schema({
    type: String,
    isActive: Boolean,
    costOfPeriod: Number,
    totalEmission:Number,
    isComplete:{
        type:Boolean,
        required:false
    }
});

const buldingSchema = mongoose.Schema({
    id: String,
    emissionId: String,
    userId: String,
    electricity: {
        isUsedPeriod: Boolean,
        costOfPeriod: Number,
        isComplete:{
            type:Boolean,
            required:false
        },
        electricityTotalEmission:Number
    },
    heatingUp: {
        isUsedPeriod: Boolean,
        heatedTypes: [heatingTypeSchema],
        required:false
    },
    coolingDown: {
        isUsedPeriod: Boolean,
        costOfPeriod: Number,
        coolingDownTotalEmssion:Number,
        isComplete:{
            type:Boolean,
            required:false
        }
    },
    generators: {
        isUsedPeriod: Boolean,
        generatorTypes: [generatorTypeSchema],
        required:false
    },
    buildingTotalEmissions:{
        type:Number,
        required:false
    }
},
{
    timestamps:true
}
);

module.exports = mongoose.model("building",buldingSchema,"building")