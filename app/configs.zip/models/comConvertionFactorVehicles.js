"use strict"

const serviceLocator = require("../lib/service_locator");
const mongoose = serviceLocator.get("mongoose");

const ComvehicleConvertionSchema = mongoose.Schema({
    fuels: {
        bioPetrol: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        mineralPetrol: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        diesel: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        lpg: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        lng: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        },
        cng: {
            Co2e_of_Co2_unit: {
                type: Number,
                required: false
            },
            Co2e_of_Ch4_unit: {
                type: Number,
                required: false
            },
            Co2e_of_N2O_unit: {
                type: Number,
                required: false
            }
        }
    },
    fuelOil: {
        Co2e_of_Co2_unit: {
            type: Number,
            required: false
        },
        Co2e_of_Ch4_unit: {
            type: Number,
            required: false
        },
        Co2e_of_N2O_unit: {
            type: Number,
            required: false
        }
    },
    lubricants: {
        Co2e_of_Co2_unit: {
            type: Number,
            required: false
        },
        Co2e_of_Ch4_unit: {
            type: Number,
            required: false
        },
        Co2e_of_N2O_unit: {
            type: Number,
            required: false
        }
    },
    trailerRefrigeration: {
        price: {
            type: Number,
            required: false
        },
        Co2e_of_Co2_unit: {
            type: Number,
            required: false
        },
        Co2e_of_Ch4_unit: {
            type: Number,
            required: false
        },
        Co2e_of_N2O_unit: {
            type: Number,
            required: false
        },
        Co2e_unit: {
            type: Number,
            required: false
        }
    },
    airCondition: {
        price: {
            type: Number,
            required: false
        },
        Co2e_of_Co2_unit: {
            type: Number,
            required: false
        },
        Co2e_of_Ch4_unit: {
            type: Number,
            required: false
        },
        Co2e_of_N2O_unit: {
            type: Number,
            required: false
        },
        Co2e_unit: {
            type: Number,
            required: false
        }
    }

})
module.exports = mongoose.model("commercialVehicleConverion", ComvehicleConvertionSchema, "commercialVehicleConverion");